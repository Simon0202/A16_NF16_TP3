#include <stdio.h>
#include <stdlib.h>
#include "library.h"

T_Produit *creerProduit(char *marque, float prix, char qualite, int quantite);
T_Rayon *creerRayon(char *nom);
T_Magasin *creerMagasin(char *nom);

int main(int argc, const char * argv[]) {

    return 0;
}
